﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InPatientRegistration.Models;
using System.Data.Entity.Core.Objects;
using System.Windows.Forms;
using System.Net;

namespace InPatientRegistration.Controllers
{
    public class DoctorController : Controller
    {
        //
        // GET: /Doctor/
        public ActionResult Doctordetails()
        {
            return View();
        }

        [HttpGet]
        public ActionResult AddNewDoctor()
        {

            return View();
        }
        [HttpPost]
        public ActionResult AddNewDoctor(AddDoctorvalidate doc)
        {
            if (ModelState.IsValid)
            {
                PatientEntities dbContext = new PatientEntities();
                ObjectParameter statusParam = new ObjectParameter("doctorId", typeof(string));

                dbContext.uspaddDoctor(statusParam, doc.docname, doc.Qualification, doc.specilization, doc.docMobile, doc.docusername, doc.docpassword);
                if (statusParam.Value != null)
                {
                    MessageBox.Show("Doctor ID is" + statusParam.Value);
                }
                else
                {
                    MessageBox.Show("Not Yet Registered");
                }
            }
            else
            {
                return View();
            }

            return View();
        }

        public ActionResult AddDoctor()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddDoctor(tbldoctor doc)
        {
            PatientEntities dbContext = new PatientEntities();
            ObjectParameter statusParam = new ObjectParameter("doctorId", typeof(string));

            dbContext.uspaddDoctor(statusParam, doc.docname, doc.Qualification, doc.specilization, doc.docMobile, doc.docusername, doc.docpassword);
            if (statusParam.Value != null)
            {
                MessageBox.Show("Doctor ID is" + statusParam.Value);
            }
            else
            {
                MessageBox.Show("Not Yet Registered");
            }

            return View();
        }
       
        public ActionResult ViewAllDoc()
        {
            PatientEntities dbContext = new PatientEntities();
         
            return View(dbContext.tbldoctors.ToList());
        }
        public ActionResult Delete( string id)
        {
            PatientEntities dbContext = new PatientEntities();
            var del = dbContext.tbldoctors.Where(s => s.docId == id).FirstOrDefault();


            return View(del);
        }
        [HttpPost,ActionName("Delete")]
        public ActionResult DeletePost(string id)
        {
            
            DialogResult res = MessageBox.Show("Are you Sure to Delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == DialogResult.Yes)
            {
                PatientEntities db = new PatientEntities();
                tbldoctor tbldoctor = db.tbldoctors.FirstOrDefault(s => s.docId == id);
                db.tbldoctors.Remove(tbldoctor);
                db.SaveChanges();
                return RedirectToAction("ViewAllDoc", "Doctor");
            }
            else

                return RedirectToAction("Delete", "Doctor");
        }
        

        
	}
}

