﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace InPatientRegistration.Models
{
    public class AddDoctorvalidate
    {
        [Required(ErrorMessage = "Please provide Doctorname")]
        [DisplayName("Doctor Name")]
        public string docname { get; set; }

        [Required][DisplayName("Qualification")]
        public string Qualification { get; set; }

        [Required][DisplayName("Specialization")]
        public string specilization { get; set; }

        [Required][DisplayName("Mobile")]
        public string docMobile { get; set; }

        [Required][DisplayName("User Name")]
        public string docusername { get; set; }

        [Required][DisplayName("Password")]
        public string docpassword { get; set; }
    }
}
