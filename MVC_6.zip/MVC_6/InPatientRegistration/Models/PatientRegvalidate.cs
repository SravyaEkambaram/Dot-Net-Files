﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace InPatientRegistration.Models
{
    public class PatientRegvalidate
    {
        [Required][DisplayName("First Name")]
        public string firstName { get; set; }

        [Required][DisplayName("Last Name")]
        public string lastName { get; set; }

        [Required][DisplayName("CareTaker Name")]
        public string caretakername { get; set; }

        [Required][DisplayName("Mobile")]
        [StringLength(10)]
        [RegularExpression("[7-9]{1}\\d{9}", ErrorMessage = "Provide a valid 10 digit mobile number")]
        public string mobile { get; set; }

        [Required][DisplayName("Address")]
        public string address { get; set; }

        [Required][DisplayName("Email")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Please enter a valid e-mail adress")]
        public string email { get; set; }

        [Required][DisplayName("Occupation")]
        public string occupation { get; set; }

        [Required][DisplayName("Organisation Working For")]
        public string organisationworking { get; set; }

        [Required][DisplayName("Joining Date")]
        public DateTime JoiningDate { get; set; }

        [Required][DisplayName("Gender")]
        public string gender { get; set; }

        [Required][DisplayName("Reason")]
        public string Reason { get; set; }

        [Required][DisplayName("Username")]
        public string username { get; set; }

        [Required][DisplayName("Password")]
        [DataType(DataType.Password)]
        public string password { get; set; }
         
            
    }
}