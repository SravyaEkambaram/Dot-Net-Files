﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureDealers
{
        public class Furniture
        {         
            public string Name { get; set; }
            public int furniturecode;
            public int FurnitureCode { get { return furniturecode; } }
            public int noofModels { get; set; }
            public string Category { get; set; }
            public int seats;
        
        }
}
