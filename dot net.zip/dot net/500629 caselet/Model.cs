﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureDealers
{
    class Model : Furniture
    {
        static int stock;
        int flag1 = 0;
        int ustock;
        int count = 0;

        //public Model()
        //{
        //}
        
        public int id { get; set; }
        public string model { get; set; }
        public double price { get; set; }
        public Boolean instock { get; set; }

        static public List<Model> list = new List<Model>();
        public Model(int a, string m, double p, Boolean b)
        {
            this.id = a;
            this.model = m;
            this.price = p;
            this.instock = b;
        }
        double cal_vat(double i)
        {
            return (i * 0.045);
        }
        public override string ToString()
        {
            Console.WriteLine(Convert.ToString(id));
            Console.WriteLine(Convert.ToString(price));
            Console.WriteLine(Convert.ToString(model));
            Console.WriteLine(Convert.ToString(instock));
            return null;
        }
        public void add_model()
        {
            Model mod = new Model();
            Console.WriteLine("\n Add New Model\n");
            Console.WriteLine("Enter funiture category \n1 Dining table \n2 Sofa Set \n3 Office Desk");
            int catogery = Convert.ToInt32(Console.ReadLine());
            switch (catogery)
            {
                case 1:
                    mod.Category = "Dining Table";
                    break;
                case 2:
                    mod.Category = "Sofa Set";
                    break;
                case 3:
                    mod.Category = "Office Desk";
                    break;
                default:
                    Console.WriteLine("Wrong Choice ");
                    Console.ReadKey();
                    new Model().add_model();
                    break;
            }
            Console.WriteLine("Enter Model Name:");
            StringBuilder MyStringBuilder = new StringBuilder(modelname);
            string modelname = Console.ReadLine();

            foreach (char c in modelname)
            {
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')))
                {
                    Console.WriteLine("Enter the Alphabets");
                    break;
                }
                else
                {
                    mod.Name = modelname;
                    Random r = new Random();
                    mod.furniturecode = r.Next(400, 600);
                    Console.WriteLine("\n Furniture code:" + mod.furniturecode);
                    mod.id = r.Next(1, 100);
                    Console.WriteLine("\n Furniture ID :" + mod.id);
                    Console.WriteLine("\nPlease enter the price:");
                    mod.price = Convert.ToDouble(Console.ReadLine());

                    double vat = cal_vat(mod.price);
                    Console.WriteLine("\n Your VAT is:" + vat);

                    Console.WriteLine("\nEnter number of seats:");
                    mod.seats = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("\nEnter the number of stock:");
                    stock = Convert.ToInt32(Console.ReadLine());
                    mod.ustock = stock;
                    list.Add(mod);
                    return;
                }
            }
        }
        public void delete_model()
        {
            int choice;
            Console.WriteLine("\n Delete a Model\n");
            Console.WriteLine(" Enter the model ID which is to be removed:\n");
            choice = Convert.ToInt32(Console.ReadLine());
            foreach (Model dm in list)
            {
                if (dm.id == choice)
                {
                    list.Remove(dm);
                    count = count + 1;
                    dm.ustock--;
                    break;
                }
            }
            if (count == 0)
            {
                Console.WriteLine(" No Id Found");
            }
        }
        public void display_allmodels()
        {
            Model mod = new Model();
            foreach (var obj in list)
            {
                Console.WriteLine("id is {0}",obj.id);
                Console.WriteLine("category is {0}",obj.Category);
                Console.WriteLine("furniture code is {0}",obj.furniturecode);
                Console.WriteLine("name is {0}",obj.Name);
                Console.WriteLine("price is {0}",obj.price);
            }
        }
        public void modify_price()
        {
            Console.WriteLine("Enter the id of the item:\n");
            int tempid = Convert.ToInt32(Console.ReadLine());
            foreach (Model li in list)
            {
                if (li.id == tempid)
                {
                    Console.WriteLine("Enter the Price to be Added");
                    int price = Convert.ToInt32(Console.ReadLine());
                    li.price = li.price + price;
                    break;
                }
            }
        }
        public void lowest_priced_model()
        {
            double lowest_price = Double.MaxValue;

            foreach (Model a in list)
            {
                if (a.price < lowest_price)
                {
                    lowest_price = a.price;
                    Console.WriteLine("The lowest price of any model is: " + a.price);
                }
            }
        }
        public void modelsln_Aprice_range()
        {
            Console.WriteLine("Please Enter the starting price range");
            double start = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please Enter the ending price range");
            double end = Convert.ToDouble(Console.ReadLine());
            foreach (Model a in list)
            {
                if (a.price > start && a.price < end)
                {
                    Console.WriteLine("ID:", a.id);
                    Console.WriteLine("Category:", a.Category);
                    Console.WriteLine(a.furniturecode);
                    Console.WriteLine(a.Name);
                    Console.WriteLine("Price:{0}", a.price);
                }
                else
                {
                    Console.WriteLine("Not in Range");
                }
            }
        }
        public void display_1model()
        {
            Console.WriteLine("Enter the product Id to display details");
            int temp1 = Convert.ToInt32(Console.ReadLine());

            foreach (Model a in list)
            {
                if (a.id == temp1)
                {
                    Console.WriteLine(a.id);
                    Console.WriteLine(a.Category);
                    Console.WriteLine(a.furniturecode);
                    Console.WriteLine(a.Name);
                    Console.WriteLine(a.price);
                }
            }
        }
        public void check_avalability()
        {
            Console.WriteLine("check for product id");
            int prodtemp = Convert.ToInt32(Console.ReadLine());

            foreach (Model a in list)
            {
                if (a.id == prodtemp)
                {
                    if (a.ustock > 0)
                    {
                        Console.WriteLine("Present");
                        flag1 = flag1++;
                    }
                }
            }
            if (flag1 == 0)
            {
                Console.WriteLine("Underflow");
            }
        }
    }
}
