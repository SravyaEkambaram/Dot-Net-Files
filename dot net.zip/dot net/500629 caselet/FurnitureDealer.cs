﻿using FurnitureDealers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureDealers
{  
    class Program
    {
        static void Main(string[] args)
        {
            char ch;
            do
            {
                Model add = new Model();
                Console.WriteLine("My Fashion Furnitures");
                Console.WriteLine("1. Add Model");
                Console.WriteLine("2. Delete Model");
                Console.WriteLine("3. Display all Models");
                Console.WriteLine("4. Price modificaton");
                Console.WriteLine("5. Model with lowest price");
                Console.WriteLine("6. Models with  price Range");
                Console.WriteLine("7. Price of a model");
                Console.WriteLine("8. Check Availability");                
                Console.WriteLine("Enter Your Choice:");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        add.add_model();
                        break;
                    case 2:
                        add.delete_model();
                        break;
                    case 3:
                        add.display_allmodels();
                        break;
                    case 4:
                        add.modify_price();
                        break;
                    case 5:
                        add.lowest_priced_model();                      
                        break;
                    case 6:
                        add.modelsln_Aprice_range();                       
                        break;
                    case 7:
                        add.display_1model();                       
                        break;
                    case 8:
                        add.check_avalability();
                        break;
                    default:
                        Console.WriteLine("Wrong selection! Select from 1 to 8 Only");
                        break;
                }
                Console.WriteLine("To continue select Y or N");
                ch = Convert.ToChar(Console.ReadLine());
            } while ((ch == 'y') || (ch == 'Y'));
            Console.ReadKey();
        }
    }
}


