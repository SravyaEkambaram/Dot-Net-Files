﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extsayhello
{
    class Program
    {
        static class Myext
        {
            public static void Sayhello(this Employee e)
            {

            }
        }
    }
    class extensiondemo
    {
        static void Main(string[] args)
        {
            Employee e = new Employee { ID = 7, name = "john" };
            e.Sayhello();
        }
    }
}
