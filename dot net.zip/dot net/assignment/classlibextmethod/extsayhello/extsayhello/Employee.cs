﻿using System;

namespace extsayhello
{
    internal class Employee
    {
        public int ID { get; set; }
        public string name { get; set; }

        internal void Sayhello()
        {
            throw new NotImplementedException();
        }
    }
}