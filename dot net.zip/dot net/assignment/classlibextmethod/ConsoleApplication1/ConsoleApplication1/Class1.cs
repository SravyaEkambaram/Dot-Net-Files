﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media;
namespace ConsoleApplication1
{
     class Program
       {
            [STAThread]
            static void Main(string[] args)
            {
                Window window = new Window();
                window.Height = 200;
                window.Width = 300;
                window.Title = "My First WPF";

                Button btn = new Button();
                btn.Height = 200;
                btn.Width = 300;
                btn.Content = "Click";
                btn.Click += Btn_Click;
               // btn.Click += (s, e) => { MessageBox.Show("Hello TechM"); };
                window.Content = btn;
                Application app = new Application();
                app.Run(window);
            }
            private static void Btn_Click(object sender, RoutedEventArgs e)
            {
                MessageBox.Show("Hello");
            }
        }
}