﻿using System.Windows.Controls;

namespace ConsoleApplication1
{
    internal class Window
    {
        internal static int height;
        internal static string title;
        internal static int width;

        public Button Content { get; internal set; }
        public int Height { get; internal set; }
        public string Title { get; internal set; }
        public int Width { get; internal set; }
    }
}