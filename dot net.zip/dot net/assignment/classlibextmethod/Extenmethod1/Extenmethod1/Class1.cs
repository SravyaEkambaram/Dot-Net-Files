﻿using System;

namespace Extenmethod1
{
    internal class Class1
    {
        internal void Print()
        {
            throw new NotImplementedException();
        }

        internal void Display()
        {
            throw new NotImplementedException();
        }
    }
}