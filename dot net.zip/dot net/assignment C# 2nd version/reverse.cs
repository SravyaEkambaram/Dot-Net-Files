﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverse_version2
{
    class Program
    {
        static void Main(string[] args)
        {         
            Console.WriteLine("enter number");
            int n = Convert.ToInt32(Console.ReadLine());          
            foreach (char c in n.ToString().Reverse())
            {
                Console.Write(c);
            }
            Console.ReadLine();
        }
    }
}
