﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace meanmedstd_version2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[6];
            for (int i = 0; i < numbers.Length; i++)
            {

                numbers[i] = Convert.ToInt32(Console.ReadLine());
                
            }
            double mean = numbers.Average();
            Console.WriteLine($"mean is {mean}");


            int numbercount = numbers.Count();
            int halfindex = numbers.Count() / 2;
            var sortednumbers = numbers.OrderBy(n => n);
            double median;
            if ((numbercount % 2) == 0)
            {
                median = ((sortednumbers.ElementAt(halfindex) +
                    sortednumbers.ElementAt((halfindex - 1))) / 2);
            }
            else
            {
                median = sortednumbers.ElementAt(halfindex);
            }
            Console.WriteLine($"median is {median}");



            int mode = numbers.GroupBy(n => n).
                    OrderByDescending(g => g.Count()).
                     Select(g => g.Key).FirstOrDefault();
                    Console.WriteLine($"mode is {mode}");

            Console.ReadLine();






        }
    }
}
