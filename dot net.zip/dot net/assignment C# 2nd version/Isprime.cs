﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Isprimemethod
{
    class Isprime
    {
        static void Main(string[] args)
        { 
            Console.WriteLine("Enter a number");
            int number = int.Parse(Console.ReadLine());
            bool value = IsPrimeNumber(number);
            Console.WriteLine($"result is {value}");
            Console.ReadKey();
        }
        private static bool IsPrimeNumber( int number)
        {
            int i;
            for (i = 2; i <= number-1; i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            if (i == number)
            {
                return true;
            }
            return false;
        }
    }
}

