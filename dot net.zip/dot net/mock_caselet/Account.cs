﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    public abstract class Account
    {
        public readonly long acc_Number;
        public string name;
        public int balance = 0;
        public Account()
        {
            this.acc_Number = genRandomnum();
        }       
        long genRandomnum()
        {
            long acc_num = 0;
            Random r = new Random();
            string x = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                x += r.Next(0, 9).ToString();
            }
            if (x.Length == 12)
            {
                acc_num = Convert.ToInt64(x);
            }
            return acc_num;
        }
    }
}