﻿create database ASSIGNMENT

USE ASSIGNMENT
GO
CREATE TABLE PACK_GRADES
(
grade_id      INT      NOT NULL      PRIMARY KEY,
grade_name  VARCHAR(50) NOT NULL,
min_price  money ,
max_price money
)

CREATE TABLE PACKAGES
(
pack_id      INT      NOT NULL      PRIMARY KEY,
speed		VARCHAR(100)	,
strt_date   DATE,
monthly_payment  money ,
sector_id int NOT NULL REFERENCES sectors(sector_id)
)

CREATE TABLE SECTORS
(
sector_id INT		NOT NULL PRIMARY KEY,
sector_name VARCHAR(50) NOT NULL
)

CREATE TABLE CUSTOMERS
(
customer_id      INT      NOT NULL      PRIMARY KEY,
First_Name  VARCHAR(50) NOT NULL,
Last_Name  VARCHAR(50) NULL,
birth_date   DATE,
join_date DATE,
city  VARCHAR(50),
state VARCHAR(50),
street VARCHAR(50),
main_phone_num VARCHAR(15),
secondary_phone_num VARCHAR(15),
fax VARCHAR(50),
monthly_discount  MONEY ,
pack_id int NOT NULL REFERENCES packages(pack_id)
)
 
--INSERTING VALUES

--INSERTING VALUES INTO PACKAGES

INSERT packages VALUES(1,'750Kbps',CAST(0x5C2C0B00 AS Date),79,1)
INSERT packages VALUES(2,'750Kbps',CAST(0x8D2D0B00 AS Date),69,1)
INSERT packages VALUES(3,'750Kbps',CAST(0x092E0B00 AS Date),59,1)
INSERT packages VALUES(4,'750Kbps',CAST(0x05300B00 AS Date),49,1)
INSERT packages VALUES(5,'750Kbps',CAST(0xF9310B00 AS Date),39,1)
INSERT packages VALUES(6,'750Kbps',CAST(0x51320B00 AS Date),29,1)
INSERT packages VALUES(7,'750Kbps',CAST(0xA42B0B00 AS Date),69,2)
INSERT packages VALUES(8,'750Kbps',CAST(0x7D2D0B00 AS Date),59,2)
INSERT packages VALUES(9,'750Kbps',CAST(0x342F0B00 AS Date),49,2)
INSERT packages VALUES(10,'750Kbps',CAST(0x9C300B00 AS Date),39,2)
INSERT packages VALUES(11,'750Kbps',CAST(0x29320B00 AS Date),29,2)
INSERT packages VALUES(12,'750Kbps',CAST(0x2C330B00 AS Date),19,2)
INSERT packages VALUES(13,'1.5Mbps',CAST(0xBD2C0B00 AS Date),89,1)
INSERT packages VALUES(14,'1.5Mbps',CAST(0xB52E0B00 AS Date),79,1)
INSERT packages VALUES(15,'1.5Mbps',CAST(0xA2300B00 AS Date),69,1)
INSERT packages VALUES(16,'1.5Mbps',CAST(0x8F310B00 AS Date),59,1)
INSERT packages VALUES(17,'1.5Mbps',CAST(0x76320B00 AS Date),49,1)
INSERT packages VALUES(18,'1.5Mbps',CAST(0x3B2D0B00 AS Date),79,2)
INSERT packages VALUES(19,'1.5Mbps',CAST(0x3C2E0B00 AS Date),69,2)
INSERT packages VALUES(20,'1.5Mbps',CAST(0xA02F0B00 AS Date),59,2)
INSERT packages VALUES(21,'1.5Mbps',CAST(0x4A310B00 AS Date),49,2)
INSERT packages VALUES(22,'1.5Mbps',CAST(0x5F320B00 AS Date),39,2)
INSERT packages VALUES(23,'2.5Mbps',CAST(0x0C2E0B00 AS Date),99,1)
INSERT packages VALUES(24,'2.5Mbps',CAST(0xD82F0B00 AS Date),89,1)
INSERT packages VALUES(25,'2.5Mbps',CAST(0xC6310B00 AS Date),79,1)
INSERT packages VALUES(26,'2.5Mbps',CAST(0x09330B00 AS Date),69,1)
INSERT packages VALUES(27,'2.5Mbps',CAST(0x8B2E0B00 AS Date),89,2)
INSERT packages VALUES(28,'2.5Mbps',CAST(0x7C2F0B00 AS Date),79,2)
INSERT packages VALUES(29,'2.5Mbps',CAST(0xEC300B00 AS Date),69,2)
INSERT packages VALUES(30,'2.5Mbps',CAST(0x66320B00 AS Date),59,2)
INSERT packages VALUES(31,'5Mbps',CAST(0x55300B00 AS Date),109,1)
INSERT packages VALUES(32,'5Mbps',CAST(0xF6300B00 AS Date),99,1)
INSERT packages VALUES(33,'5Mbps',CAST(0xDF320B00 AS Date),89,1)
INSERT packages VALUES(34,'5Mbps',CAST(0xD1300B00 AS Date),99,2)
INSERT packages VALUES(35,'5Mbps',CAST(0x24320B00 AS Date),89,2)
INSERT packages VALUES(36,'5Mbps',CAST(0x5D330B00 AS Date),79,2)
INSERT packages VALUES(37,'10Mbps',CAST(0xE8300B00 AS Date),119,1)
INSERT packages VALUES(38,'10Mbps',CAST(0xAF320B00 AS Date),109,1)
INSERT packages VALUES(39,'10Mbps',CAST(0x2A320B00 AS Date),109,2)
INSERT packages VALUES(40,'10Mbps',CAST(0x5C320B00 AS Date),99,2)
INSERT packages VALUES(41,'12Mbps',CAST(0xB2330B00 AS Date),129,1)
INSERT packages VALUES(42,'12Mbps','2005-11-03',119,2)
INSERT sectors VALUES(1,'Private')
INSERT sectors VALUES(2,'Business')
INSERT pack_grades VALUES (1, 'Very Low', 0, 10)
INSERT pack_grades VALUES (2, 'Low', 11, 20)
INSERT pack_grades VALUES (3, 'Medium', 21, 40)
INSERT pack_grades VALUES (4, 'High', 41, 80)
INSERT pack_grades VALUES (5, 'Very High', 81, 150)

INSERT customers VALUES(2,'Jose','Jones','1968-01-17',CAST(0x12300B00 AS
Date),'LosAngeles','California','4081HollisterAvenue','520.336.8373','939.115.6982','7
11.883.3345',CAST(12.00 AS Decimal(4,2)),31)

INSERT customers VALUES(1,'Alvin','Smith','1962-06-27',CAST(0x812D0B00 AS
Date),'NewYork','NewYork','5953HollisterAvenue','567.867.3945','936.228.9436','762.788
.3400',CAST(28.00 AS Decimal(4,2)),18)

INSERT customers VALUES(3,'Amado','Taylor','1965-08-17',CAST(0x802C0B00 AS
Date),'Chicago','Illinois','3402BroderickStreet','522.501.6331','976.113.3737','767.94
4.7131',NULL,7)
INSERT customers VALUES(4,'Stuart','Williams','1983-05-01',CAST(0xF32E0B00 AS
Date),'Houston','Texas','5543JenningsStreet','530.339.4737','963.891.4185','756.186.36
34',CAST(17.00 AS Decimal(4,2)),23)
INSERT customers VALUES(5,'Demarcus','Brown','1971-12-02',CAST(0xD62C0B00 AS
Date),'Philadelphia','Pennsylvania','5321LagunaStreet','580.733.2184',NULL,'760.663.20
46',CAST(11.00 AS Decimal(4,2)),13)
INSERT customers VALUES(6,'Mark','Davies','1970-09-01',CAST(0xAB310B00 AS
Date),'Phoenix','Arizona','5868CameronWay','557.701.1366','919.345.5511',NULL,CAST
(18.00 AS Decimal(4,2)),39)
INSERT customers VALUES(7,'Merlin','Evans','1962-04-13',CAST(0xD52B0B00 AS
Date),'SanAntonio','Texas','8177BrannanStreet','542.753.9215','992.959.8999',NULL,CAST
(23.00 AS Decimal(4,2)),1)
INSERT customers VALUES(8,'Elroy','Wilson','1963-01-28',CAST(0x19330B00 AS
Date),'SanDiego','California','1873KeyAvenue','544.172.1347','985.345.8501',NULL,CAST(
6.00 AS Decimal(4,2)),42)
INSERT customers VALUES(9,'Charles','Thomas','1960-05-13',CAST(0x44320B00 AS
Date),'SanJose','California','9164ValenciaStreet','515.656.3047',NULL,'799.101.7626',CAST
(29.00 AS Decimal(4,2)),37)
INSERT customers VALUES(10,'Rudolph','Roberts','1973-11-05',CAST(0x412C0B00 AS
Date),'Jacksonville','Florida','6308GilbertStreet','549.569.1762','942.671.2496','729.
973.1742',CAST(7.00 AS Decimal(4,2)),7)
INSERT customers VALUES(11,'Laurence','Johnson','1975-11-25',CAST(0xC62F0B00 AS
Date),'Indianapolis','Indiana','7529McLarenAvenue','527.138.3311','916.219.9787',NULL,
CAST(9.00 AS Decimal(4,2)),34)
INSERT customers VALUES(12,'Pasquale','Lewis','1969-05-24',CAST(0x162F0B00 AS
Date),'Austin','Texas','1569ClevelandStreet','566.849.6722','983.706.4341',NULL,NULL,27)
INSERT customers VALUES(13,'Pat','Walker','1985-07-02',CAST(0x8D300B00 AS
Date),'SanFrancisco','California','4687SloatBoulevard','582.885.8362','938.219.8802',NULL,NULL,31)
INSERT customers VALUES(14,'Harland','Robinson','1974-04-17',CAST(0xFD2F0B00 AS
Date),'Columbus','Ohio','5390MontgomeryStreet','520.519.1795','944.392.2529','721.443.
8826',CAST(30.00 AS Decimal(4,2)),31)
INSERT customers VALUES(15,'Herschel','Wood','1974-07-24',CAST(0xE9320B00 AS
Date),'FortWorth','Texas','7842CorbettAvenue','588.826.5279','997.263.1636','779.791.4
617',CAST(30.00 AS Decimal(4,2)),41)
INSERT customers VALUES(16,'Galen','Thompson','1964-12-08',CAST(0x902B0B00 AS
Date),'Charlotte','NorthCarolina','5466FarragutAvenue','599.783.7133',NULL,'753.251.64
33',CAST(16.00 AS Decimal(4,2)),1)
INSERT customers VALUES(17,'Brain','White','1978-02-13',CAST(0x1F300B00 AS
Date),'Detroit','Michigan','3728IngersonStreet','561.654.2679','957.711.4041','794.811
.7354',NULL,34)
INSERT customers VALUES(18,'Marcel','Watson','1978-10-12',CAST(0x452E0B00 AS
Date),'ElPaso','Texas','9157LeidesdorffStreet','567.827.2421','937.806.4116','723.277.
6166',CAST(28.00 AS Decimal(4,2)),23)
INSERT customers VALUES(19,'Lino','Jackson','1982-06-25',CAST(0x2E2E0B00 AS
Date),'Memphis','Tennessee','4542McKinnonAvenue','557.460.8507','984.433.8202','792.90
8.7024',CAST(6.00 AS Decimal(4,2)),27)
INSERT customers VALUES(20,'Riley','Wright','1970-02-18',CAST(0x2B2B0B00 AS
Date),'Boston','Massachusetts','4848VallejoStreet','541.661.3366','931.368.3046','737.
625.7424',CAST(21.00 AS Decimal(4,2)),1)

--3
SELECT * FROM CUSTOMERS
--4
SELECT pack_id,speed,monthly_payment FROM PACKAGES
--5
SELECT customer_id,First_Name ,Last_Name,main_phone_num,secondary_phone_num,pack_id FROM CUSTOMERS

--6
SELECT First_Name ,Last_Name,join_date,monthly_discount,
       (monthly_discount+0.2) AS monthly_discount_adding_20percent,(monthly_discount-0.2) as monthly_discount_reducing_20percent 
       FROM CUSTOMERS
--7
SELECT pack_id,speed,strt_date,monthly_payment,(monthly_payment*12) AS YearlyPayment 
FROM PACKAGES
--8
SELECT  CONCAT(First_Name, ' ', Last_Name) AS FULL_NAME, 
        CONCAT(main_phone_num,' ', ',',secondary_phone_num) AS CONTACT_DETAILS FROM customers
--9
SELECT distinct city FROM CUSTOMERS
--10
SELECT distinct state FROM CUSTOMERS
--11
SELECT distinct city,state FROM CUSTOMERS
--12
SELECT  CONCAT(Last_Name, ' ', state) AS CUSTOMER_AND_STATE 
FROM CUSTOMERS
--13
SELECT First_Name AS FN ,Last_Name AS LN,monthly_discount DC,
       CONCAT(city, ' ', street) AS FULL_ADDRESS 
FROM CUSTOMERS
--14
SELECT distinct monthly_discount from CUSTOMERS
--15
SELECT distinct pack_id from CUSTOMERS
--16
SELECT First_Name,Last_Name,pack_id FROM CUSTOMERS
WHERE Last_Name='king'
--SELECT * FROM PACKAGES
--17
SELECT * FROM PACKAGES 
WHERE speed='5Mbps'
--18
SELECT First_Name ,Last_Name,monthly_discount,pack_id FROM CUSTOMERS
WHERE monthly_discount<30
--19
SELECT * FROM CUSTOMERS 
WHERE join_date<'2007-01-01'
--20
SELECT customer_id,First_Name,state,city,pack_id FROM CUSTOMERS
WHERE pack_id IN(21,28,14)
--21
SELECT customer_id,First_Name,state,city,pack_id FROM CUSTOMERS
WHERE pack_id NOT IN(27,10,03)
--22
SELECT Last_Name,main_phone_num,monthly_discount,pack_id FROM CUSTOMERS
WHERE customer_id  IN(703,314,560)
--23
SELECT First_Name,monthly_discount FROM CUSTOMERS
WHERE First_Name LIKE '%e'
--24
SELECT Last_Name,pack_id FROM CUSTOMERS
WHERE Last_Name LIKE '_d%'
--25
SELECT * FROM CUSTOMERS
WHERE Last_Name LIKE '%l%' OR Last_Name LIKE '%j%' OR Last_Name LIKE '%h%'
ORDER BY monthly_discount desc
--26
SELECT First_Name, join_date,monthly_discount,pack_id FROM CUSTOMERS
WHERE Last_Name NOT LIKE '%a%'
ORDER BY pack_id
--27
SELECT * FROM CUSTOMERS 
WHERE pack_id IS NULL
--28
SELECT  CONCAT(First_Name, ' ', Last_Name) AS FULL_NAME,monthly_discount FROM CUSTOMERS
WHERE monthly_discount NOT BETWEEN 20 AND 30
ORDER BY FULL_NAME
--29
SELECT  CONCAT(First_Name, ' ', Last_Name) AS FULL_NAME,
        CONCAT(main_phone_num,' ',street) AS CONTACTS,monthly_discount AS DC 
FROM    CUSTOMERS
WHERE   monthly_discount BETWEEN 11 AND 27
--30 a
SELECT * FROM CUSTOMERS 
WHERE city='New York' AND  monthly_discount BETWEEN 30 AND 40
--30 b
SELECT * FROM CUSTOMERS
WHERE pack_id NOT IN(8,19,30) AND join_date<'2007-01-01'
--31
SELECT Last_Name,birth_date,pack_id FROM CUSTOMERS
WHERE join_date BETWEEN '2007-12-12'AND '2010-04-17'
--32
SELECT pack_id,strt_date,speed FROM PACKAGES
WHERE strt_date<'2007-01-01'
--33
SELECT pack_id,speed,sector_id FROM PACKAGES
WHERE sector_id=1  
--34
SELECT pack_id,speed,sector_id FROM PACKAGES
WHERE speed='5Mbps' OR speed='10Mbps'
--35
SELECT Last_Name,monthly_discount FROM CUSTOMERS
WHERE city='Orlando'
--36
SELECT Last_Name,pack_id FROM CUSTOMERS
WHERE pack_id IN(9,18)
SELECT Last_Name,pack_id FROM CUSTOMERS
WHERE pack_id=9 OR pack_id=18
--37
SELECT First_Name,main_phone_num,secondary_phone_num FROM CUSTOMERS
WHERE secondary_phone_num IS NULL 
--38
SELECT First_Name,monthly_discount,pack_id FROM CUSTOMERS
WHERE monthly_discount IS NULL
--39
SELECT customer_id,lower(First_Name),upper(Last_Name) FROM CUSTOMERS
WHERE customer_id BETWEEN 80 AND 150
--40 a
SELECT First_Name,Last_Name,concat(substring(First_Name,1,1),upper((substring(Last_Name,1,3))),'@mymail.com') as email_address
FROM CUSTOMERS​
--40 b
select First_Name,Last_Name,concat(substring(First_Name,1,1),
       upper((substring(Last_Name,len(Last_Name)-2,3))),'@mymail.com') as email_address
FROM CUSTOMERS
--41
SELECT Last_name , LEN(Last_name)
FROM CUSTOMERS
WHERE LEN(Last_name) > 9 
--42 a
SELECT first_name , last_name , main_phone_num , REPLACE(main_phone_num , '515' , '$$$') AS 'New_Phone_Number'
FROM CUSTOMERS
WHERE main_phone_num LIKE '%515%'

--42 b
 SELECT first_name , last_name , main_phone_num ,
        REPLACE(LEFT(main_phone_num, 3) , '515' , '$$$') + SUBSTRING(main_phone_num , 4 , 12) AS 'New_Phone_Number'
FROM CUSTOMERS
WHERE main_phone_num LIKE '515%'

--43
SELECT  first_name ,
         monthly_discount,
         monthly_discount + 0.197 AS MD_after_addition ,
         ROUND(monthly_discount + 0.197 , 2) AS round,
         FLOOR(monthly_discount + 0.197 ) AS floor,
         CEILING(monthly_discount + 0.197 ) AS ceiling
FROM CUSTOMERS
 --44
 SELECT  first_name , join_date,
         DATEADD(dd, -10 , join_date),
         DATEADD(mm , 1 , join_date),
         DATEDIFF(dd , join_date , getdate())
FROM CUSTOMERS 
--45
 SELECT first_name , birth_date , DATEDIFF(yy , birth_date , getdate())
FROM CUSTOMERS
WHERE DATEDIFF(yy , birth_date , getdate()) > 50 
--46
SELECT first_name , birth_date
FROM CUSTOMERS
WHERE MONTH(birth_date) = MONTH(getdate())
              AND
              DAY(birth_date) = DAY(getdate())
--47
SELECT first_name , join_date , DATEDIFF(yy , join_date , getdate())
FROM CUSTOMERS
WHERE DATEDIFF(yy , join_date , getdate()) = 5
             AND
              MONTH(join_date) = MONTH(getdate())
              AND
              DAY(join_date) = DAY(getdate())
--48
SELECT first_name +  ' / '  + CAST(DAY(join_date) AS VARCHAR)  AS Firstname_withdate,
              Last_name +  ' / '   + CAST(monthly_discount AS VARCHAR) AS Lastname_withdate
FROM CUSTOMERS

--49

SELECT  Last_Name,
                UPPER(state) + ' / ' + CONVERT(varchar , customer_id ) AS State_Customerid,
                CONVERT(varchar ,join_date ) + ' / ' + CONVERT(varchar , birth_date ) AS Joindate_Birthdate
FROM CUSTOMERS
WHERE SUBSTRING(last_name , 1 , 1) IN ('D' , 'K')

--50a
SELECT  first_name , last_name ,birth_date,
        ISNULL(main_phone_num , 'N / A'),
        ISNULL(secondary_phone_num, 'N / A')             
FROM CUSTOMERS
WHERE pack_id = 27 

--50b
SELECT  first_name ,last_name , birth_date ,
	    ISNULL(main_phone_num , 'N / A'),
	    ISNULL(secondary_phone_num, 'N / A')
             
FROM CUSTOMERS
WHERE pack_id = 27
AND year(birth_date) = 1972 
 --51
 SELECT first_name , last_name , monthly_discount ,
              CASE WHEN monthly_discount BETWEEN 0 AND 10 THEN 'A'
                WHEN monthly_discount BETWEEN 11 AND 20 THEN 'B'
                WHEN monthly_discount BETWEEN 21 AND 30 THEN 'C'
                ELSE 'D'
             END AS 'Grades'
FROM CUSTOMERS 
--52
SELECT MIN(Last_Name)
FROM CUSTOMERS
--53
SELECT AVG(monthly_discount) AS AVG_OF_MONTHLY_DISCOUNT
FROM CUSTOMERS
--54
SELECT MAX(Last_Name)
FROM CUSTOMERS
--55
SELECT COUNT(pack_id) FROM PACKAGES 
--56
SELECT COUNT(*) FROM CUSTOMERS
--57
SELECT COUNT(DISTINCT(state)) AS DISTINCT_STATES FROM CUSTOMERS
--58
SELECT COUNT(DISTINCT(pack_id)) AS DISTINCT_INTERNET_PACKAGES FROM PACKAGES

--59
SELECT COUNT(fax) AS NUMBER_OF_VALUES FROM CUSTOMERS  WHERE fax IS NOT NULL
--60
SELECT COUNT(*) -COUNT(fax) FROM CUSTOMERS
--61
SELECT  MIN(monthly_discount) AS MIN_MD,
    MAX(monthly_discount) AS MAX_MD,
    AVG(monthly_discount) AS AVG_MD
FROM CUSTOMERS 
 --62
 SELECT state,COUNT(*) AS NUM_OF_CUSTOMERS
FROM CUSTOMERS
GROUP BY state 
--63
SELECT  speed,AVG(monthly_payment) AS AVG_OF_MONTHLY_PAYMENT 
FROM PACKAGES
GROUP BY speed
--64
SELECT state, COUNT(DISTINCT city) AS DISTINCT_CITY
FROM CUSTOMERS
GROUP BY state 
--65
SELECT sector_id,MAX(monthly_payment) AS HIGHEST_MP
FROM PACKAGES
GROUP BY sector_id
--66 a
SELECT pack_id,AVG(monthly_payment) AS AVG_MD
FROM PACKAGES
GROUP BY pack_id

--66 b
SELECT pack_id,AVG(monthly_payment) AS AVG_MD
FROM PACKAGES
GROUP BY pack_id
HAVING pack_id IN(22,13)
--67
 SELECT speed , MIN(monthly_payment) AS MIN_MP , MAX(monthly_payment) AS MAX_MP  , AVG(monthly_payment) AS AVG_MP
 FROM   PACKAGES
 GROUP BY speed  
 --68 a
  SELECT pack_id , COUNT(*) AS NO_OF_CUSTOMERS
 FROM  CUSTOMERS
 GROUP BY pack_id 
 --68b
 SELECT pack_id , COUNT(*) AS NO_OF_CUSTOMERS
 FROM  CUSTOMERS
 GROUP BY pack_id ,monthly_discount
 HAVING monthly_discount>20
 --68c
  SELECT pack_id , COUNT(*) AS NO_OF_CUSTOMERS
 FROM  CUSTOMERS
 GROUP BY pack_id
 HAVING COUNT(*) >100
 --69
 SELECT state, city, COUNT(*) AS NO_OF_CUSTOMERS
 FROM  CUSTOMERS
 GROUP BY state, city
 --70 a
 SELECT city,AVG(monthly_discount) AS AVG_MD FROM  CUSTOMERS
 GROUP BY city
--70 b
 SELECT city,AVG(monthly_discount) AS AVG_MD FROM  CUSTOMERS
 GROUP BY city,monthly_discount
 HAVING monthly_discount>20
 --71 a
 SELECT MIN(monthly_discount) AS MIN_MD , state
 FROM CUSTOMERS
 GROUP BY state
 --71 b
  SELECT MIN(monthly_discount) AS MIN_MD , state
 FROM CUSTOMERS
 GROUP BY state
 HAVING MIN(monthly_discount) >10
 --72
 SELECT COUNT(*) , speed
 FROM PACKAGES
 GROUP BY speed
 HAVING COUNT(*) > 8
 --73 a
 SELECT c.last_name , c.first_name , c.pack_id , p.speed
FROM CUSTOMERS c JOIN PACKAGES p
ON  c.pack_id = p.pack_id 

 --73 b
 SELECT c.last_name , c.first_name , c.pack_id , p.speed
FROM CUSTOMERS c JOIN PACKAGES p
ON  c.pack_id = p.pack_id 
WHERE c.pack_id IN (27, 22)
ORDER BY c.last_name 

--74 a 
 SELECT p.pack_id , p.speed, p.monthly_payment, s.sector_name
FROM PACKAGES p JOIN SECTORS s
ON  p.sector_id = s.sector_id
--74 b
SELECT c.last_name , c.first_name , p.pack_id , p.speed, p.monthly_payment, s.sector_name
FROM PACKAGES p JOIN SECTORS s
ON  p.sector_id = s.sector_id
JOIN CUSTOMERS c
ON  c.pack_id = p.pack_id
--74 c
SELECT c.last_name , c.first_name , p.pack_id , p.speed, p.monthly_payment, s.sector_name
FROM PACKAGES p JOIN SECTORS s
ON  p.sector_id = s.sector_id
JOIN CUSTOMERS c
ON  c.pack_id = p.pack_id
WHERE s.sector_name='business'
--75
SELECT c.last_name , c.first_name , p.pack_id , p.speed, p.monthly_payment, s.sector_name
FROM PACKAGES p JOIN SECTORS s
ON   p.sector_id = s.sector_id
JOIN CUSTOMERS c
ON   c.pack_id = p.pack_id
WHERE s.sector_name = 'Private' AND year(c.join_date) = 2006 
 --76
 SELECT p.pack_id  , p.speed, p.monthly_payment, pg.grade_id
FROM PACKAGES p JOIN PACK_GRADES pg
ON  p.pack_id = pg.grade_id
--77 a
SELECT c.first_name , c.last_name ,  p.speed, p.monthly_payment,p.pack_id
FROM  CUSTOMERS c  JOIN PACKAGES p 
ON      c.pack_id = p.pack_id
--77 b
SELECT c.first_name , c.last_name ,  p.speed, p.monthly_payment,c.pack_id
FROM  CUSTOMERS c LEFT OUTER  JOIN PACKAGES p 
ON   c.pack_id = p.pack_id 

--77 C

SELECT c.first_name , c.last_name ,  p.speed, p.monthly_payment,c.pack_id
FROM CUSTOMERS c RIGHT OUTER  JOIN PACKAGES p 
ON   c.pack_id = p.pack_id 
--77 d
SELECT c.first_name , c.last_name ,  p.speed, p.monthly_payment,c.pack_id
FROM CUSTOMERS c FULL OUTER  JOIN PACKAGES p 
ON   c.pack_id = p.pack_id 

--78 
SELECT c.last_name , c.first_name , c.pack_id
FROM CUSTOMERS c JOIN CUSTOMERS c1
ON c1.last_name = 'Taylor' AND c1.first_name = 'Amado'
AND      c1.pack_id = c.pack_id

--79

SELECT c.last_name , c.first_name , c.pack_id , c1.monthly_discount
FROM CUSTOMERS c JOIN CUSTOMERS c1
ON c1.Customer_Id = 103
AND c.monthly_discount < c1.monthly_discount

--80
 
 SELECT p1.pack_id , p1.speed
FROM    PACKAGES p1 JOIN PACKAGES p2
ON         p2.pack_id = 10
AND       p1.speed = p2.speed
/*OR*/
SELECT pack_id,speed
FROM  PACKAGES
WHERE speed= (SELECT speed FROM  PACKAGES WHERE pack_id=10)

--81
SELECT first_name , last_name , state, city
FROM CUSTOMERS
WHERE state = (SELECT state FROM CUSTOMERS WHERE customer_id = 170)

--82
SELECT pack_id, speed , sector_id
FROM PACKAGES
WHERE sector_id = (SELECT sector_id FROM PACKAGES WHERE pack_id = 10)
--83
SELECT first_name , last_name , join_date
FROM CUSTOMERS
WHERE join_date > (SELECT join_date FROM CUSTOMERS WHERE customer_id = 540)
 --84
SELECT first_name , last_name , join_date
FROM CUSTOMERS
WHERE year(join_date) = (SELECT year( join_date) FROM CUSTOMERS WHERE customer_id = 372)
AND
month(join_date) = (SELECT month(join_date) FROM CUSTOMERS WHERE customer_id = 372)

--85
SELECT first_name , last_name , city , state, pack_id
FROM CUSTOMERS
WHERE pack_id IN (SELECT pack_id FROM PACKAGES WHERE speed = '5Mbps')

--86

SELECT pack_id , speed , strt_date
FROM PACKAGES
WHERE year(strt_date) = (SELECT year(strt_date) FROM PACKAGES WHERE pack_id = 7)

--87

SELECT first_name , monthly_discount , pack_id , main_phone_num , secondary_phone_num
FROM CUSTOMERS
WHERE pack_id IN(SELECT pack_id FROM PACKAGES
WHERE sector_id IN(SELECT sector_id FROM SECTORS
WHERE sector_name = 'Business'))

--88

SELECT first_name , monthly_discount, pack_id
FROM CUSTOMERS
WHERE pack_id IN (SELECT  pack_id FROM PACKAGES
 WHERE monthly_payment >(SELECT AVG(monthly_payment) FROM PACKAGES))
 
 
 --89
 SELECT customer_id , first_name , city , state ,birth_date , monthly_discount
FROM CUSTOMERS
WHERE birth_date =(SELECT birth_date FROM CUSTOMERS WHERE customer_id = 179)
AND monthly_discount >(SELECT monthly_discount FROM CUSTOMERS WHERE customer_id = 107)

--90
 SELECT * FROM PACKAGES
 WHERE speed=(SELECT speed FROM PACKAGES WHERE pack_id=30)
 AND monthly_payment >(SELECT monthly_payment FROM PACKAGES WHERE pack_id = 7)

 --91
 SELECT pack_id,speed,monthly_payment
 FROM PACKAGES
 WHERE monthly_payment>(SELECT MAX(monthly_payment) FROM PACKAGES WHERE speed ='5Mbps')

 --92

 SELECT pack_id,speed,monthly_payment
 FROM PACKAGES
 WHERE monthly_payment>(SELECT MIN(monthly_payment) FROM PACKAGES WHERE speed ='5Mbps')

 --93
 SELECT pack_id,speed,monthly_payment
 FROM PACKAGES
 WHERE monthly_payment< (SELECT MIN(monthly_payment) FROM PACKAGES WHERE speed ='5Mbps')

 --94
 SELECT first_name ,monthly_discount , pack_id
FROM CUSTOMERS
WHERE monthly_discount < (SELECT AVG(monthly_discount) FROM CUSTOMERS)
AND pack_id IN (SELECT pack_id FROM CUSTOMERS WHERE first_name = 'Kevin')


 












Select * from PACKAGES

Select * from CUSTOMERS

select* from SECTORS

select * from pack_grades


SELECT c.pack_id, p.pack_id
FROM  customers c RIGHT JOIN packages p 
ON   c.pack_id = p.pack_id 


select pack_id from PACKAGES