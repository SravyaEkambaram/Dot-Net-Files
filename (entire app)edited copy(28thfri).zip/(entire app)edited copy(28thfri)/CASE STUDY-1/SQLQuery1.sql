--create database Railways
create database Railways
----registration table
create table tblRegisterInfo
(
userId int primary key identity(10000,1),
FirstName varchar(50),
LastName varchar(max),
Pwd varchar(max),
Email varchar(max),
Phn varchar(10),
Gender varchar(10),
UserType int
)
ALTER TABLE	tblRegisterInfo
DROP COLUMN UserType

select * from tblRegisterInfo

----usp for Regis Info
create proc uspRegisterUser
@firstName varchar(50),
@lastName varchar(max),
@password varchar(max),
@gender varchar(10),
@emailId varchar(max),
@mobile varchar(10),


as
begin
insert into tblRegisterInfo values
(@firstName,@lastName,@password,@gender,@emailId,@mobile)
end


--GetNewId
create proc uspGetNewId @id int output
as
begin
if not exists(select * from tblRegisterInfo)
set @id=10001
else
select @id=MAX(userId)+1 from tblRegisterInfo
end

declare @id int
exec uspGetNewId @id out
print 'New Id'
print @id


--stored procedure to check for user existence in the table
create proc uspCheckUser
@uid int,
@pwd varchar(max),
@res int out
as
begin
if exists(select * from tblRegisterInfo
where userId=@uid and Pwd=@pwd )
set @res=1
else
set @res=0
end


--drop down list : Zones n Divisions
create table tblZone
(
Zone_id int primary key,  
Zone_name varchar(max)  
)


create table tblDivision
(
Division_id int  primary key,  
Division_name varchar(30),  
Zone_id int foreign key references tblZone(Zone_id)  
)


create proc uspSelectZone
@zoneId int,
@zoneName varchar(max),
@res int out
as
begin
if exists(select * from tblZone where
Zone_id=@zoneId and Zone_name=@zoneName)
set @res=1
else
set @res=0
end


create proc uspSelectDivision
@divId int,
@divName varchar(max),
@zoneId int,
@res int out
as
begin
if exists(select Division_id,Division_name  from tblDivision 
where Zone_id=@zoneId)
set @res=1
else
set @res=0
end

select * from tblZone

select * from tblDivision

DELETE FROM "tblDivision"
WHERE "Division_id"=0;


--Admin train info
create table tblTotalTrainInfo
(
train_id int primary key,
train_name varchar(max),
Zone_id int,
Zone_name varchar(max),
Division_id int,
Division_name varchar(30),
train_source varchar(max),
train_destination varchar(max),
trains_totTrains int,
train_seatsTotal int,
train_seatsBooked int,
train_seatsAvailable int,
--train_bookDate date,
train_upTripStD int,
train_downTripStD int,
train_trainsToBeIncd int
)

select * from tblTotalTrainInfo

alter table tblTotalTrainInfo drop column train_bookDate

----sp for Admin Train Data
create Procedure uspTotalTrainInfo
(
 -- variable  declarations 
 @Action Varchar (10),    --to perform operation according to string attached to this varible such as Insert,update,delete,select      
 @id int,
 @source varchar(max),
 @destination varchar(max),
 @totTrains int,
 @seatsTotal int,
 @seatsBooked int,
 @seatsAvailable int,
 @upTripStD int,
 @downTripStD int,
 @trainsToBeIncd int
 
)
as
Begin 
  SET NOCOUNT ON;

If @Action='Insert'   --used to insert records
Begin
   Insert Into tblTotalTrainInfo (train_id,train_source,train_destination,trains_totTrains,
   train_seatsTotal,train_seatsBooked,train_seatsAvailable,train_upTripStD,
   train_downTripStD,train_trainsToBeIncd)
   values(@id,@source,@destination,@totTrains,@seatsTotal,@seatsBooked,
   @seatsAvailable,@upTripStD,@downTripStD,@trainsToBeIncd)
End  
else if @Action='Select'   --used to Select records
Begin
    select *from tblTotalTrainInfo
end
else if @Action='Update'  --used to update records
Begin
   update tblTotalTrainInfo set train_source=@source,train_destination=@destination,
   trains_totTrains=@totTrains,train_seatsTotal=@seatsTotal,
   train_seatsBooked=@seatsBooked,train_seatsAvailable=@seatsAvailable,
   train_upTripStD=@upTripStD,train_downTripStD=@downTripStD,
   train_trainsToBeIncd=@trainsToBeIncd where train_id=@id
 End

 Else If @Action='delete'  --used to delete records
 Begin
   delete from tblTotalTrainInfo where train_id=@id
 end
 End


--update sp admin train
CREATE PROCEDURE uspUpdateTrainDet
(
 @id int,
 @source varchar(max),
 @destination varchar(max),
 @totTrains int,
 @seatsTotal int,
 @seatsBooked int,
 @seatsAvailable int,
 @upTripStD int,
 @downTripStD int,
 @trainsToBeIncd int
)
	
AS
BEGIN
	SET NOCOUNT OFF; -- Keep it off to returns no. of records affected
   
   update tblTotalTrainInfo set train_source=@source,
   train_destination=@destination,trains_totTrains=@totTrains,
   train_seatsTotal=@seatsTotal,train_seatsBooked=@seatsBooked,
   train_seatsAvailable=@seatsAvailable,train_upTripStD=@upTripStD,
   train_downTripStD=@downTripStD,train_trainsToBeIncd=@trainsToBeIncd 
   where train_id=@id

END

-- delete sp admin train

CREATE PROCEDURE uspDeleteTrainDet
 (
 @id int,
 @source varchar(max),
 @destination varchar(max),
 @totTrains int,
 @seatsTotal int,
 @seatsBooked int,
 @seatsAvailable int,
 @upTripStD int,
 @downTripStD int,
 @trainsToBeIncd int
 )
AS
BEGIN
	SET NOCOUNT OFF; -- Keep it off to returns no. of records affected

	delete from tblTotalTrainInfo where train_id=@id

END

--table to book tkt
create table tblbooktkt
(
trainName varchar(max), 
tsource varchar(max),
tdestination varchar(max),
bdate varchar(max),
tkttype int
)
select * from tblbooktkt

--usp for book tkt
create proc uspbooktkt

@trainName varchar(max), 
@tsource varchar(max),
@tdestination varchar(max),
@bdate varchar(max),
@tkttype int
as
begin
insert into tblbooktkt values (@trainName,@tsource,@tdestination,@bdate,@tkttype)
end



select * from tblRegisterInfo

--disp custname.. sessions
create proc uspGetCustName 
@id int,
@fnm varchar(max) out
as
begin
set @fnm=(select FirstName from tblRegisterInfo 
where userId=@id)
end


alter table tblRegisterInfo
alter column FirstName varchar(50)
