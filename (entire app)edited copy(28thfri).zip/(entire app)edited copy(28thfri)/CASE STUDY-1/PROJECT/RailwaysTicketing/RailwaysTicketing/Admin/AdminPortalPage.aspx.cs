﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Railways_BL;
using System.Data;

namespace RailwaysTicketing
{
    public partial class AdminPortalPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["AdminName"] == null || Session["AdminName"].ToString() == string.Empty)
            {
                MessageBox.Show("You are currently not logged in..!!");
                Response.Redirect("~/General/CustomerLoginPage.aspx");

            }
            lblAdmin.Text = "Welcome Admin....!!!";
            gvTotTrainInfo.Visible = false;
           
 
        }


       
        protected void lnkChkTrainRoutes_Click(object sender, EventArgs e)
        {
            gvTotTrainInfo.Visible = true;

        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("AdminName");
            Response.Redirect("~/General/CustomerLoginPage.aspx");
        }

        










        

        
    }
}