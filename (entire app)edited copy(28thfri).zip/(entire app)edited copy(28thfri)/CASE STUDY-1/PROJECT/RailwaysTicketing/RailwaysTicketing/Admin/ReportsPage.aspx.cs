﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace RailwaysTicketing.Admin
{
    public partial class ReportsPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["AdminName"] == null || Session["AdminName"].ToString() == string.Empty)
            {
                MessageBox.Show("You are currently not logged in..!!");
                Response.Redirect("~/General/CustomerLoginPage.aspx");

            }
            //lblAdmin.Text = "Welcome Admin....!!!";
            gvViewRep.Visible = false;
        }

        protected void btnRep_Click(object sender, EventArgs e)
        {
            gvViewRep.Visible = true;
        }
    }
}