﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Railways_BL;
using System.Windows.Forms;

namespace RailwaysTicketing
{
    public partial class ModificationsPage : System.Web.UI.Page
    {
        BusinessLogics businessLogicsObject;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["AdminName"] == null || Session["AdminName"].ToString() == string.Empty)
            {
                MessageBox.Show("You are currently not logged in..!!");
                Response.Redirect("~/General/CustomerLoginPage.aspx");

            }
            //lblAdmin.Text = "Welcome Admin....!!!";
        }
        
        protected void btnUpdate_Click1(object sender, EventArgs e)
        {
            businessLogicsObject = new BusinessLogics();
            int id = Convert.ToInt32(txtTrainID.Text);
            string source = Convert.ToString(txtSource.Text);
            string destination = Convert.ToString(txtDestination.Text);
            int totTrains = Convert.ToInt32(txtTotTrains.Text);
            int totSeats = Convert.ToInt32(txtTotSeats.Text);
            int totSeatsBkd = Convert.ToInt32(txtSeatsBkd.Text);
            int totSeatsAvail = Convert.ToInt32(txtSeatsAvai.Text);
            int upTrips = Convert.ToInt32(txtUpTrips.Text);
            int downTrips = Convert.ToInt32(txtDownTrips.Text);
            int TrainsInc = Convert.ToInt32(txtTrainsInc.Text);

            int result = businessLogicsObject.UpdateTrainDetails(Convert.ToInt32(txtTrainID.Text),txtSource.Text, txtDestination.Text,
                Convert.ToInt32(txtTotTrains.Text), Convert.ToInt32(txtTotSeats.Text), Convert.ToInt32(txtSeatsBkd.Text), Convert.ToInt32(txtSeatsAvai.Text),
                Convert.ToInt32(txtUpTrips.Text), Convert.ToInt32(txtDownTrips.Text), Convert.ToInt32(txtTrainsInc.Text));
            if (result != 0)
            {
                MessageBox.Show("Update Failed...!!");
                Response.Redirect("~/Admin/AdminPortalPage.aspx");
                
            }
               
            else
            {
                MessageBox.Show("Updated successful...!!");
                Response.Redirect("~/Admin/AdminPortalPage.aspx");

            }
                
        }


        protected void btnDelete_Click1(object sender, EventArgs e)
        {
            DialogResult dlgResult = MessageBox.Show("You are about to delete...\nAre you sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dlgResult == DialogResult.Yes)
            {
                businessLogicsObject = new BusinessLogics();
                int id = Convert.ToInt32(txtTrainID.Text);
                int res = businessLogicsObject.DeleteTrainDetails(id);
                if (res != 0)
                {
                    MessageBox.Show("Deleted successful...");
                    Response.Redirect("~/Admin/AdminPortalPage.aspx");
                }
                else
                {
                    MessageBox.Show("Delete Failed");
                    Response.Redirect("~/Admin/AdminPortalPage.aspx");
                }
            }
            else
            {
                MessageBox.Show("Thank you for not deleting", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtTrainID.Text = "";
            txtSource.Text="";
            txtDestination.Text="";
            txtTotTrains.Text="";
            txtTotSeats.Text="";
            txtSeatsBkd.Text="";
            txtSeatsAvai.Text="";
            txtUpTrips.Text="";
            txtDownTrips.Text="";
            txtTrainsInc.Text = "";

            Response.Redirect("~/Admin/AdminPortalPage.aspx");


        }

        
    }
}