﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Railways_DAL
{
    public class DataLogics
    {

        //public static string GetConnection()
        //{
        //    return ConfigurationManager.ConnectionStrings["RailwaysConnectionString"].ConnectionString.ToString();
        //}
        
        
        public static SqlConnection GetConnection()
        {
            SqlConnection conObject = new SqlConnection("Data Source=INHYTCPCO5329;Initial Catalog=Railways;Integrated Security=True");
            conObject.Open();
            return conObject;
        }

        //Registered User code
        public int RegisterUserInfo(string fname, string lname, string pwd, string gender, string email, string mob,string add)
        {
            int res = 0;
            SqlConnection conObject =  GetConnection();                  
            SqlCommand registerCmdObj = new SqlCommand("uspRegisterUser", conObject);
                
                    registerCmdObj.CommandType = CommandType.StoredProcedure;
                    registerCmdObj.Parameters.AddWithValue("@firstName", fname);
                    registerCmdObj.Parameters.AddWithValue("@lastName", lname);
                    registerCmdObj.Parameters.AddWithValue("@password", pwd);
                    registerCmdObj.Parameters.AddWithValue("@gender", gender);
                    registerCmdObj.Parameters.AddWithValue("@emailId", email);
                    registerCmdObj.Parameters.AddWithValue("@mobile", mob);
                    registerCmdObj.Parameters.AddWithValue("@address", add);

            //registerCmdObj.Parameters.AddWithValue("@uType", utype);

            registerCmdObj.ExecuteNonQuery();

                    return res;
                
            
        }

        //Generate Unique Id
        public int GetNewId()
        {
            SqlConnection conObject = GetConnection();
            SqlCommand cmd = new SqlCommand("uspGetNewId", conObject);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter idParam = new SqlParameter("@id", SqlDbType.Int);
            idParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(idParam);

            cmd.ExecuteReader();

            return Convert.ToInt32(idParam.Value);
        }

        //check for user existence
        public bool CheckUserForExistence(int uid, string pwd)
        {
            SqlConnection conObject = GetConnection();
            SqlCommand cmd = new SqlCommand("uspCheckUser", conObject);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@uid", uid);
            cmd.Parameters.AddWithValue("@pwd", pwd);
            //cmd.Parameters.AddWithValue("@uType", utype);

            SqlParameter resParameter = new SqlParameter("@res", SqlDbType.Int);
            resParameter.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(resParameter);

            cmd.ExecuteReader();
            if ((int)resParameter.Value == 1)
                return true;
            else
                return false;
        }

        //ddl zone n div
        public static DataTable GetZoneList(int Zone_id, string Zone_name, int res)
        {
            SqlConnection conObject = GetConnection();
            SqlCommand cmd = new SqlCommand("uspSelectZone", conObject);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@zoneId", Zone_id);
            cmd.Parameters.AddWithValue("@zoneName", Zone_name);
            cmd.Parameters.AddWithValue("@res", res);


            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
                dt = new DataTable("tblZone");
                dt.Load(dr);
                return dt;
            }
            if (cmd != null)
            {
                cmd.Dispose();
                cmd = null;
            }
            return dt;
        }

        public static DataTable GetDivisionList(int Zone_id, int Division_id, string Division_name, int res)
        {
            SqlConnection conObject = GetConnection();
            SqlCommand cmd = new SqlCommand("uspSelectDivision", conObject);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@zoneId", SqlDbType.Int).Value = Zone_id;
            cmd.Parameters.AddWithValue("@divId", Division_id);
            cmd.Parameters.AddWithValue("@divName", Division_name);
            cmd.Parameters.AddWithValue("@res", res);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
                dt = new DataTable("tblDivision");
                dt.Load(dr);

                return dt;
            }
            if (cmd != null)
            {
                cmd.Dispose();
                cmd = null;
            }
            return dt;
        }

        // update data in grid view
        public int UpdateTrainDet(int id, string source, string destination, int totTrains, int seatsTotal, int seatsBooked, int seatsAvailable, int upTripStD, int downTripStD, int trainsToBeIncd)
        {
            var returnValue = 0;
            SqlConnection conObject = GetConnection();
            SqlCommand cmd = new SqlCommand("uspUpdateTrainDet", conObject);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@source", source);
            cmd.Parameters.AddWithValue("@destination", destination);
            cmd.Parameters.AddWithValue("@totTrains", totTrains);
            cmd.Parameters.AddWithValue("@seatsTotal", seatsTotal);
            cmd.Parameters.AddWithValue("@seatsBooked", seatsBooked);
            cmd.Parameters.AddWithValue("@seatsAvailable", seatsAvailable);
            cmd.Parameters.AddWithValue("@upTripStD", upTripStD);
            cmd.Parameters.AddWithValue("@downTripStD", downTripStD);
            cmd.Parameters.AddWithValue("@trainsToBeIncd", trainsToBeIncd);


            cmd.ExecuteNonQuery();
            return returnValue;
        }


        // delete data in grid view
        public int DeleteTrainDet(int id)
        {
            SqlConnection conObject = GetConnection();
            SqlCommand cmd = new SqlCommand("uspDeleteTrainDet", conObject);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id", id);

            return cmd.ExecuteNonQuery();
        }

        //customer tkt bukn
        public int CustomerTktBuknDet(string trainName, string tsource, string tdestination, string bdate, int tkttype)
        {
            int res = 0;
            SqlConnection conObject = GetConnection();
            SqlCommand registerCmdObj = new SqlCommand("uspbooktkt", conObject);
            registerCmdObj.CommandType = CommandType.StoredProcedure;
            registerCmdObj.Parameters.AddWithValue("@trainName", trainName);
            registerCmdObj.Parameters.AddWithValue("@tsource", tsource);
            registerCmdObj.Parameters.AddWithValue("@tdestination", tdestination);
            registerCmdObj.Parameters.AddWithValue("@bdate", bdate);
            registerCmdObj.Parameters.AddWithValue("@tkttype", tkttype);

            registerCmdObj.ExecuteNonQuery();

            return res;
        }

        //show cust name sessions
        public String GetCustnm(int custId)
        {
            SqlConnection conObject = GetConnection();
            SqlCommand cmd = new SqlCommand("uspGetCustName ", conObject);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@id", custId);

            SqlParameter idParameter = new SqlParameter("@fnm", SqlDbType.VarChar, 50);
            idParameter.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(idParameter);
            cmd.ExecuteReader();
            return idParameter.Value.ToString();

        }
    }

}










