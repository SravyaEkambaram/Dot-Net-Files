﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RailwaysTicketing
{
    public partial class MainPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/General/CustomerLoginPage.aspx");
        }

        protected void btnBukn_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Customer/TicketBooking.aspx");
        }

        protected void btnRep_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Admin/ReportsPage.aspx");
        }

        //protected void btnAbtUs_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("~/General/AboutUsPage.aspx");
        //}

       
        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/General/AboutUs.aspx");
        }

        protected void btnContUs_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/General/ContactUsPage.aspx");
        }
    }
}