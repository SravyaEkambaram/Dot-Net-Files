﻿using Railways_BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace RailwaysTicketing.Admin
{
    public partial class TicketBooking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            btnSubmit.Visible = false;

            if (Session["CustomerName"] == null || Session["CustomerName"].ToString() == string.Empty)
            {
                MessageBox.Show("You are currently not logged in..!!");
                Response.Redirect("~/General/CustomerLoginPage.aspx");

            }
            lblCustNm.Text = "Welcome " + Session["CustomerName"] + "...!!";
            btnSubmit.Enabled = false;
        }
        BusinessLogics businessLogicsObject;

        protected void btnCalChose_Click(object sender, EventArgs e)
        {
            Calendar1.Visible = true;
            btnSubmit.Enabled = true;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtCalDate.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

       

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("CustomerName");
            Response.Redirect("~/General/CustomerLoginPage.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            businessLogicsObject = new BusinessLogics();
            int res = businessLogicsObject.CustomertktBkInfo(txtTrainName.Text,txtSource.Text,txtDestination.Text,txtCalDate.Text,Convert.ToInt32(rbtnTktType.SelectedItem.Value));
            if(res==1)
            {
                MessageBox.Show("Booking Failed","Information",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Booking Successfull..!!","Confirmation",MessageBoxButtons.OK,MessageBoxIcon.Information);
                Response.Redirect("~/General/HomePage.aspx");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            businessLogicsObject = new BusinessLogics();
            int res = businessLogicsObject.CustomertktBkInfo(txtTrainName.Text, txtSource.Text, txtDestination.Text, txtCalDate.Text, Convert.ToInt32(rbtnTktType.SelectedItem.Value));
            if (res == 1)
            {
                MessageBox.Show("Booking Failed", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Booking Successfull..!!", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Response.Redirect("~/General/HomePage.aspx");
            }


        }

    }
}