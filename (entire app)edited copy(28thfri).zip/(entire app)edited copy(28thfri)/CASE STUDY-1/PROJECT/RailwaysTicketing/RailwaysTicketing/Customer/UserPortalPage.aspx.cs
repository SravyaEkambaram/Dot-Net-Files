﻿using Railways_BL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace RailwaysTicketing
{
    public partial class UserPortalPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //if (Session["CustomerName"] == null || Session["CustomerName"].ToString()==string.Empty)
            //{
            //    MessageBox.Show("You are currently not logged in..!!");
            //    Response.Redirect("~/General/CustomerLoginPage.aspx");

            //}
            lblCustNm.Text = "Welcome "; //+ Session["CustomerName"] + "...!!";
            int i = 0;
            string s = string.Empty;
            int r = 0;
            if (!Page.IsPostBack)
            {

                ddlZone.Items.Add("--Select Zone--");
                ddlZone.Items.Add("Northern Railway");
                ddlZone.Items.Add("Central Railway");
                ddlZone.Items.Add("Eastern Railway");
                ddlZone.Items.Add("Western Railway");
                ddlZone.Items.Add("Southern Railway");

                BindZone(i, s, r);


            }
        }
             public void BindZone(int Zone_id, string Zone_name, int res)
        {

            BusinessLogics DDL = new BusinessLogics();

            DataTable dtZone = Railways_BL.BusinessLogics.ZoneList(Zone_id, Zone_name, res);
            ddlZone.DataSource = dtZone;
            ddlZone.DataValueField = "Zone_id";
            ddlZone.DataTextField = "Zone_name";

            ddlZone.DataBind();
            ddlZone.Items.Insert(0, new ListItem("---Select Zone---"));

        }

        protected void ddlZone_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDivision();
            
            if (ddlZone.SelectedItem.Text == "Northern Railway")
            {

                ddlDiv.Items.Clear();
               
                ddlDiv.Items.Add("Delhi");
                ddlDiv.Items.Add("Ambala");
                ddlDiv.Items.Add("Lucknow");
                ddlDiv.Items.Add("Firozpur");
            }
            else if (ddlZone.SelectedItem.Text == "Central Railway")
            {
                ddlDiv.Items.Clear();
                
                ddlDiv.Items.Add("Mumbai");
                ddlDiv.Items.Add("Pune");
                ddlDiv.Items.Add("Solapur");
                ddlDiv.Items.Add("Nagpur");
            }

            else if (ddlZone.SelectedItem.Text == "Eastern Railway")
            {
                ddlDiv.Items.Clear();
                
                ddlDiv.Items.Add("Howrah");
                ddlDiv.Items.Add("Sealdah");
                ddlDiv.Items.Add("Asansol");
                ddlDiv.Items.Add("Malda");
            }

            else if (ddlZone.SelectedItem.Text == "Western Railway")
            {
                ddlDiv.Items.Clear();
                
                ddlDiv.Items.Add("Mumbai_WR");
                ddlDiv.Items.Add("Ahmedabad");
                ddlDiv.Items.Add("Rajkot");
                ddlDiv.Items.Add("Ratlam");
            }

            else if (ddlZone.SelectedItem.Text == "Southern Railway")
            {
                ddlDiv.Items.Clear();

                ddlDiv.Items.Add("Chennai");
                ddlDiv.Items.Add("Madurai");
                ddlDiv.Items.Add("Thiruvananthapuram");
                ddlDiv.Items.Add("Tiruchirappalli");
            }
        
        }
         public void BindDivision()
        {
            int Zone_id = 0, Division_id = 0, res = 0;
            string Division_name = string.Empty;
            int.TryParse(ddlDiv.SelectedValue, out Zone_id);

            DataTable dtCity = Railways_BL.BusinessLogics.DivisionList(Zone_id, Division_id, Division_name, res);

            ddlDiv.DataSource = dtCity;
            ddlDiv.DataTextField = "Division_name";
            ddlDiv.DataValueField = "Division_id";
            ddlDiv.DataBind();
            ddlDiv.Items.Insert(0, new ListItem("---Select Division---"));
        }


        protected void ddlDiv_SelectedIndexChanged(object sender, EventArgs e)
        {
             MessageBox.Show("Division name selected = " + ddlDiv.SelectedItem.Text);
        }


        protected void btnChkAvai_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Customer/TicketBooking.aspx");
        }

        }


    }
