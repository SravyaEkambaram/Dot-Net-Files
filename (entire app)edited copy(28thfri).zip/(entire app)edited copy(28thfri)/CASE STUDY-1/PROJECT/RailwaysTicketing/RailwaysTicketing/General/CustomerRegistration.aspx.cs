﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Railways_BL;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace RailwaysTicketing
{
    public partial class CustomerRegistration : System.Web.UI.Page
    {
        BusinessLogics businessLogicsObject;
        //private SqlCommand cmd;
        //private SqlConnection sqlcon;
        protected void Page_Load(object sender, EventArgs e)
        {
            
           
        }

       

        protected void btnSubmit_Click1(object sender, EventArgs e)
        {
            businessLogicsObject = new BusinessLogics();
            if (txtPwd.Text == txtCpwd.Text)
            {
                int res = businessLogicsObject.RegisterUser(txtFnm.Text, txtLnm.Text, txtPwd.Text, txtEmail.Text, txtPhn.Text, rdbtnlsGender.SelectedItem.Value);
                
                if (res == 1)
                {
                    MessageBox.Show("Registration Failed", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {

                    MessageBox.Show("Registration is successfull", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    int id = businessLogicsObject.GetAutoId();
                    if (id != 0)
                    {
                        MessageBox.Show("Your user id for reference = " + id, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Response.Redirect("~/General/CustomerLoginPage.aspx");
                    }

                    else
                    {
                        MessageBox.Show("You are not a registered user...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }


                }
            }
            
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFnm.Text = "";
            txtLnm.Text = "";
            txtPwd.Text = "";
            txtPhn.Text = "";
            txtCpwd.Text = "";
            txtEmail.Text = "";
            rdbtnlsGender.ClearSelection();
            txtAddress.Text = "";

        }



    }
}