﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Railways_BL;
using System.Windows.Forms;
namespace RailwaysTicketing
{
    public partial class CustomerLoginPage : System.Web.UI.Page
    {
        BusinessLogics businessLogicsObject;
        protected void Page_Load(object sender, EventArgs e)
        {
            //txtUserID.Text = "";
            //txtPwd.Text = "";
        }

        protected void btnRegis_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/General/CustomerRegistration.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            businessLogicsObject = new BusinessLogics();
            int uid = Convert.ToInt32(txtUserID.Text);
            string pwd = txtPwd.Text;
            bool res = businessLogicsObject.CheckUserDetails(uid, pwd);

            if (!res)
            {

                Session["CustomerName"] = businessLogicsObject.ShowCustName(Convert.ToInt32(txtUserID.Text));

                MessageBox.Show("User Exists", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Response.Redirect("~/Customer/UserPortalPage.aspx");
            }

            else
            {
               

                MessageBox.Show("Invalid Credentials", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                

            }

        }

        protected void btnAdmin_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(txtUserID.Text) == 123 && txtPwd.Text == "admin123")
            {
                Session["AdminName"] = txtUserID.Text ;
                Response.Redirect("~/Admin/AdminPortalPage.aspx");
            }
            else
            {
                MessageBox.Show("You are not authorized", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        protected void txtUserID_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
