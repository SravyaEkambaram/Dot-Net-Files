﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Railways_DAL;
using System.Data.SqlClient;
using System.Data;


namespace Railways_BL
{
    
    public class BusinessLogics
    {
        DataLogics dataLogicsObject;
        public int RegisterUser(string fname, string lname, string pwd, string gender, string email, string mob)
        {
            dataLogicsObject = new DataLogics();
          return dataLogicsObject.RegisterUserInfo(fname, lname, pwd, gender, email, mob);
               
        }

        public int GetAutoId()
        {
            dataLogicsObject = new DataLogics();
            return dataLogicsObject.GetNewId();

        }

        public bool CheckUserDetails(int uid, string password)
        {
            dataLogicsObject = new DataLogics();
            bool result = dataLogicsObject.CheckUserForExistence(uid, password);
            return result;
        }
        public static DataTable ZoneList(int Zone_id, string Zone_name,int res)
        {
            return Railways_DAL.DataLogics.GetZoneList(Zone_id, Zone_name,res);  
            
               
        }

        public static DataTable DivisionList(int Zone_id, int Division_id, string Division_name, int res)
        {

            return Railways_DAL.DataLogics.GetDivisionList(Zone_id, Division_id, Division_name, res);
        }

        public int UpdateTrainDetails(int id, string source, string destination, int totTrains, int seatsTotal, int seatsBooked, int seatsAvailable, int upTripStD, int downTripStD, int trainsToBeIncd)
        {
            dataLogicsObject = new DataLogics();
            return dataLogicsObject.UpdateTrainDet(id, source, destination, totTrains, seatsTotal, seatsBooked, seatsAvailable, upTripStD, downTripStD, trainsToBeIncd);
        }

        public int DeleteTrainDetails(int id)
        {
            dataLogicsObject = new DataLogics();
            return dataLogicsObject.DeleteTrainDet(id);
        }

        public int CustomertktBkInfo(string trainName, string tsource, string tdestination, string bdate, int tkttype)
        {
            dataLogicsObject = new DataLogics();
            return dataLogicsObject.CustomerTktBuknDet(trainName, tsource, tdestination, bdate, tkttype);

        }

        public string ShowCustName(int custId)
        { 
            dataLogicsObject = new DataLogics();
            return dataLogicsObject.GetCustnm(custId);
        }
  

       
    }
}
