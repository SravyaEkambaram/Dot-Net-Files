create table #MyTable(Id bigint, Name varchar(100));
go
 
create proc [dbo].[InsertMaxValue]
as
begin
    
	declare @IdGenByCurrentDate bigint = (select cast(year(getdate()) as varchar) + cast(month(getdate()) as varchar) + + cast(day(getdate()) as varchar));
	declare @LastId bigint = (select max(id) from #MyTable);
	declare @NewId bigint = cast(@IdGenByCurrentDate as varchar(100)) + '0001';
 
	if @LastId is not null	
	begin
		declare @LastIdGenByCurrentDate bigint = substring(cast(@LastId as varchar(100)), 1, len(@IdGenByCurrentDate));
 
		if @IdGenByCurrentDate = @LastIdGenByCurrentDate		
			set @NewId = @LastId + 1;			
	end
	insert into #Mytable(Id,Name) values (@NewId, cast(getdate() as varchar(111)));
end
 
exec InsertMaxValue
 
select * from #MyTable