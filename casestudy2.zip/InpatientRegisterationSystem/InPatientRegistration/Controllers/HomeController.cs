﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InPatientRegistration.Models;
using System.Data.Entity;

namespace InPatientRegistration.Controllers
{
    public class HomeController : Controller
    {
        public static List<tblPatientRegistration> patlist;

        private static List<tblPatientRegistration> GetAllPats()
        {
            PatientEntities db = new PatientEntities();

            patlist = db.tblPatientRegistrations.ToList();
            return patlist;
        }
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult HealthTips()
        {
            return View();
        }
        public ActionResult Logout()
        {
            return View();
        }
        public ActionResult PatientLogin()
        {
            return View();
        }
        public ActionResult MyProfile()
        {
            if (patlist == null)
                patlist = GetAllPats();
            string username = Session["userName"].ToString();
            tblPatientRegistration patFound = null;

            foreach (var item in patlist)
            {
                if (item.username == username)
                {
                    patFound = item;
                    break;
                }
            }

            if (patFound != null)
                return View(patFound);

            else
                return RedirectToAction("Index");

        }

        public ActionResult Aboutus()
        {
            return View();
        }

        public ActionResult Contactus()
        {
            return View();
        }

        public ActionResult Blog()
        {
            return View();
        }

        public ActionResult Services()
        {
            return View();
        }

      
	}
}