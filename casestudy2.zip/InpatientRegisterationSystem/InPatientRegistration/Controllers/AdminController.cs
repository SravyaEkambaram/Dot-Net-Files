﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InPatientRegistration.Models;
using System.Data.Entity.Core.Objects;
using System.Windows.Forms;

namespace InPatientRegistration.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/
        public ActionResult AdminLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AdminLogin(AdminLogin login)
        {
            if (ModelState.IsValid)
            {
                PatientEntities dbContext = new PatientEntities();
                ObjectParameter statusParam = new ObjectParameter("exists", typeof(int));

                dbContext.adminLogin(login.Username, login.Password, statusParam);
                if (Convert.ToInt32(statusParam.Value) == 1)
                {

                    MessageBox.Show("Login Successfull", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return RedirectToAction("AdminDetails", "Admin");
                }
                else
                {
                    MessageBox.Show("Invalid Credentials");
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

                    public ActionResult AdminDetails()
                    {
                        return View();
                    }

        }
    }
