﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InPatientRegistration.Models;
using System.Data.Entity.Core.Objects;
using System.Windows.Forms;

namespace InPatientRegistration.Controllers
{
    public class PatientController : Controller
    {

        //public static List<tblPatientRegistration> patlist;

        //private static List<tblPatientRegistration> GetAllPats()
        //{
        //    PatientEntities db = new PatientEntities();

        //    patlist = db.tblPatientRegistrations.ToList();
        //    return patlist;
        //}
        //
        // GET: /Patient/
        public ActionResult NewPatientRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult NewPatientRegister(PatientRegvalidate reg)
        {
            if (ModelState.IsValid)
            {
                PatientEntities dbContext = new PatientEntities();
                ObjectParameter statusParam = new ObjectParameter("patientid", typeof(string));

                string date = reg.JoiningDate.ToString();
               

                dbContext.uspPatientRegistration(reg.firstName, reg.lastName, reg.caretakername, reg.mobile, reg.address, reg.email, reg.occupation, reg.organisationworking,reg.JoiningDate, reg.gender, reg.Reason, reg.username, reg.password, statusParam);
                if (statusParam.Value != null)
                {
                    //Session["patientid"] = reg.patientid;

                    MessageBox.Show("Registeration Id is" + statusParam.Value);
                }
                else
                {
                    MessageBox.Show("Not Yet Registered");
                }
            }
            return View();
        }
        public ActionResult PatientRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult PatientRegister(tblPatientRegistration reg)
        {
            if(ModelState.IsValid)
            {
                PatientEntities dbContext = new PatientEntities();
                ObjectParameter statusParam = new ObjectParameter("patientid", typeof(string));

                dbContext.uspPatientRegistration(reg.firstName, reg.lastName, reg.caretakername, reg.mobile, reg.address, reg.email, reg.occupation, reg.organisationworking, reg.JoiningDate, reg.gender, reg.Reason, reg.username, reg.Password, statusParam);
                if(statusParam.Value!=null)
                {
                    //Session["patientid"] = reg.patientid;
                    
                    MessageBox.Show("Registeration Id is " + statusParam.Value);
                }
                else
                {
                    MessageBox.Show("Not Yet Registered");
                }
            }
            return View();
        }

        //public ActionResult ViewOnePatient()
        //{
        //    if (patlist == null)
        //        patlist = GetAllPats();
        //    string username = Session["userName"].ToString();
        //    tblPatientRegistration patFound = null;

        //    foreach (var item in patlist)
        //    {
        //        if (item.username == username)
        //        {
        //            patFound = item;
        //            break;
        //        }
        //    }

        //    if (patFound != null)
        //        return View(patFound);

        //    else
        //        return RedirectToAction("Index");

        //}

        public ActionResult PatientLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult PatientLogin(PatientSignIn login)
        {
            if (ModelState.IsValid)
            {
                PatientEntities dbContext = new PatientEntities();
                ObjectParameter statusParam = new ObjectParameter("exists", typeof(Int32));

                dbContext.uspLogindetails(login.Username, login.Password, statusParam);
                if (Convert.ToInt32(statusParam.Value) == 1)
                {
                    Session["userName"] = login.Username;
                    MessageBox.Show("Welcome "  + login.Username);
                    return RedirectToAction("PatientLogin", "Home");
                }
                else
                {
                    MessageBox.Show("Invalid Credentials");
                }
            }
            return View();
        }
        public ActionResult Patientdetails()
        {
            return View();
        }
        public ActionResult ViewAllPatient()
        {
            PatientEntities dbContext = new PatientEntities();
            
            return View(dbContext.tblPatientRegistrations.ToList());
        }
        public ActionResult DeletePat(string id)
        {
            PatientEntities dbContext = new PatientEntities();
            var del = dbContext.tblPatientRegistrations.Where(s => s.patientid == id).FirstOrDefault();
            return View(del);
        }
        [HttpPost,ActionName("DeletePat")]
        public ActionResult Delete(string id)
        {
            DialogResult res = MessageBox.Show("Are you Sure to Delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == DialogResult.Yes)
            {
                PatientEntities db = new PatientEntities();
               tblPatientRegistration pat= db.tblPatientRegistrations.FirstOrDefault(s => s.patientid == id);
                db.tblPatientRegistrations.Remove(pat);
                db.SaveChanges();
                return RedirectToAction("ViewAllPatient", "Patient");
            }
            else

                return RedirectToAction("DeletePat", "Patient");
            
        }

        public ActionResult Accomodation()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Accomodation(Accomodation acc)
        {
            PatientEntities dbContext = new PatientEntities();

            var availability = acc.RoomNum + acc.BedNum;

            ObjectParameter statusParam = new ObjectParameter("availabilty", typeof(Int32));
            dbContext.uspAvailabilty(statusParam);

            if (Convert.ToString(statusParam.Value) == availability)
            {
                MessageBox.Show("Room is already accomodated");
            }
            else
            {
                MessageBox.Show("Room is Alloted");
                dbContext.uspAllocate(acc.patientId, acc.RoomType, acc.RoomNum, acc.BedNum, acc.Equipment);
               
            }
            return View();
        }

       
        //public ActionResult CheckAvailability(Accomodation acc)
        //{
        //    PatientEntities dbContext = new PatientEntities();
        //    var availability = acc.RoomNum + acc.BedNum;

        //    ObjectParameter statusParam = new ObjectParameter("availabilty", typeof(Int32));
        //    dbContext.uspAvailabilty(statusParam);

        //    if (Convert.ToString(statusParam.Value) == availability)
        //    {
        //        MessageBox.Show("Room is Available");
        //    }
        //    else
        //    {
        //        MessageBox.Show("Room is already accomodated");
        //    }
        //    return View();
        //}

        public ActionResult Bill()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Bill(Bill b )
        {
            PatientEntities dbContext = new PatientEntities();
            ObjectParameter statusParam = new ObjectParameter("exists", typeof(Int32));

            dbContext.uspBill(b.Patientid, b.Roomtype, b.equipment, b.PaymentMode, b.PolicyNumber, statusParam);
            if(Convert.ToInt32(statusParam.Value)==0)
            {
                MessageBox.Show("Invalid PatientID");
            }
            else
            {
                MessageBox.Show("Bill Generated");
                //dbContext.uspBill(b.Patientid, b.Roomtype, b.equipment, b.PaymentMode, b.PolicyNumber, statusParam);
                

            }
            
            return View();
        }

        public ActionResult Home()
        {
            return View();
        }
	}
}