create database Patient

use Patient

use inpatient


create table tblPatientRegistration
(
patientid varchar(5) primary key,
firstName varchar(100),
lastName varchar(100),
caretakername varchar(100),
mobile varchar(10),
address varchar(50),
email varchar(70),
occupation varchar(50),
organisationworking varchar(50),
JoiningDate date,
gender varchar(1),
Reason varchar(100),
username varchar(10),
Password varchar(20),
)

drop table  tblPatientRegistration

select * from tblPatientRegistration

alter proc uspGeneratePatientId
@patientid varchar(5) out
as
begin
declare @newId int
if(exists(select * from tblPatientRegistration))
begin
select @newId=substring(MAX(patientid),3,3)+1 from tblPatientRegistration
if(@newId>=1 and @newId<=9)
set @patientid='FP00'+cast(@newid as varchar(5))
else if(@newId>=10 and @newId<=99)
set @patientid='FP0'+cast(@newid as varchar(5))
else if(@newId>=100 and @newId<=999)
set @patientid='FP'+cast(@newid as varchar(5))
end
else 
set @patientid ='FP001'
end

create proc uspPatientRegistration

@firstName varchar(100),
@lastName varchar(100),
@caretakername varchar(100),
@mobile varchar(10),
@address varchar(50),
@email varchar(70),
@occupation varchar(50),
@organisationWorking varchar(50),
@joiningDate Date,
@gender varchar(1),
@reason varchar(100),
@userName varchar(10),
@password varchar(20),
@patientid varchar(5) out
as
begin
exec uspGeneratePatientId @patientid out
insert into tblPatientRegistration(firstName,lastName,Caretakername,mobile,address,email,occupation,organisationworking,JoiningDate,gender,Reason,userName,Password,patientid) values(@firstName,@lastName,@caretakername,@mobile,@address,@email,@occupation,@organisationworking,@JoiningDate,@gender,@Reason,@userName,@password,@patientid)
end

alter proc uspLogindetails
@username varchar(10),
@password varchar(20),
@exists int out
as
begin
if(exists(select * from tblpatientregistration where @username=username and @password=password))
set @exists=1
else
set @exists=0
end


select substring('FH001',3,3)
_________________________________________________________________________________________________

create table tbldoctor(
docId varchar(5) primary key,
docname varchar(20),
Qualification varchar(10),
specilization varchar(10),
docMobile varchar(10),
docusername varchar(20),
docpassword varchar(20))

drop table tbldoctor

select * from tbldoctor


alter proc uspGeneratedocId
@docId varchar(5) out
as
begin
declare @newId int
if(exists(select * from tbldoctor))
begin
select @newId=substring(MAX(docId),3,3)+1 from tbldoctor
if(@newId>=1 and @newId<=9)
set @docId='FD00'+cast(@newid as varchar(5))
else if(@newId>=10 and @newId<=99)
set @docId='FD0'+cast(@newid as varchar(5))
else if(@newId>=100 and @newId<=999)
set @docId='FD'+cast(@newid as varchar(5))
end
else 
set @docId ='FD001'
end

insert into tbldoctor values('admin','admin1')
create proc Dlogin
@username varchar(20),
@password varchar(20),
@res int out
as
begin
if(exists(select * from tbldoctor where @username=docusername and @password=docpassword))
set @res=1
else
set @res=0
end

alter proc uspaddDoctor
@doctorId varchar(5) out,
@doctorName varchar(20),
@qualification varchar(10),
@specialization varchar(10),
@MobileNumber varchar(10),
@UserName varchar(20),
@Password varchar(20)
as
begin
exec uspGeneratedocId @doctorId out
insert into tblDoctor(docId,docname,qualification,specilization,docmobile,docusername,docpassword) values(@doctorId,@doctorName,@qualification,@specialization,@MobileNumber,@UserName,@Password)
end														


create proc uspdeleteDoctor
@docId varchar(5),
@status int out
as
begin
if (exists(select * from tbldoctor where docId=@docId))
delete from tblDoctor where docId=@docId
set @status=1
end

create table Accomodation
(
patientId varchar(10) primary key,
RoomType varchar(20)  ,
RoomNum varchar(20)  ,
BedNum varchar(20)  ,
Equipment varchar(20)  
)

drop table Accomodation
select * from Accomodation
alter proc uspAvailabilty
@availabilty int output
as
begin
select @availabilty=Roomnum+bednum 
from Accomodation 
end


create proc uspAllocate
@patientId varchar(10),
@RoomType varchar(20),
@RoomNum varchar(20),
@BedNum varchar(20),
@equipment varchar(20)
as
begin
Insert into Accomodation(patientId,RoomType,RoomNum,BedNum,Equipment) values(@patientId,@RoomType,@RoomNum,@BedNum,@equipment)
end


create table Login(
username varchar(10) primary key,
password varchar(20))

insert into Login values('admin','admin1')
insert into Login values('operator','operator1')

select * from login

create proc adminLogin
@username varchar(20),
@password varchar(20),
@exists int out
as
begin
if(exists(select * from Login where @username=username and @password=password))
set @exists=1
else
set @exists=0
end

create proc viewalldoc
as
begin
select * from tbldoctor
end


create proc viewallpatientwithacc
as
begin
select p.patientid,p.firstName,p.lastName,p.caretakername,p.mobile,p.address,p.email,
p.occupation,p.organisationworking,p.JoiningDate,p.gender,p.Reason,a.RoomType,a.RoomNum,
a.BedNum,a.equipment from tblPatientRegistration p join Accomodation a on p.Patientid=a.Patientid
end

drop proc viewallpatientwithacc

create view viewpatientwithacc
as
select p.patientid,p.firstName,p.lastName,p.caretakername,p.mobile,p.address,p.email,
p.occupation,p.organisationworking,p.JoiningDate,p.gender,p.Reason,a.RoomType,a.RoomNum,
a.BedNum,a.equipment from tblPatientRegistration p join Accomodation a on p.Patientid=a.Patientid


drop view viewallpatientwithacc

create table Bill
(
Patientid varchar(5) primary key,
Roomtype varchar(20),
equipment varchar(20),
PaymentMode varchar(10),
PolicyNumber varchar(10))

alter proc uspBill
@Patientid varchar(5),
@Roomtype varchar(20),
@equipment varchar(20),
@PaymentMode varchar(10),
@PolicyNumber varchar(10),
@exists int out
as
begin
if (exists(select * from tblPatientRegistration where @patientid=patientid))
begin
insert into bill values(@Patientid ,@Roomtype ,@equipment ,@PaymentMode ,@PolicyNumber )
set @exists=1
end
else
set @exists=0
end

create proc insertbill
@Patientid varchar(5),
@Roomtype varchar(20),
@equipment varchar(20),
@PaymentMode varchar(10),
@PolicyNumber varchar(10)
as
begin
insert into bill values(@Patientid ,@Roomtype ,@equipment ,@PaymentMode ,@PolicyNumber )
end

select * from bill

delete from bill where patientid='FP002'

delete from tblPatientRegistration where patientid='FP003'